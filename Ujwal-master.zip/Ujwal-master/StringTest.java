package Test;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1 = "flower";
		String s2 = "flow";
		
		System.out.print(s1.indexOf(s2));

	}

}
