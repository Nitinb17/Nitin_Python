x = [1,2,3,4,5]

list = [x[-1] for x[-1] in x]
list = list[::-1]
print(list)