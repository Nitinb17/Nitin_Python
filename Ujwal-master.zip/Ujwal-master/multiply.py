res = [0] * 6

print(res)