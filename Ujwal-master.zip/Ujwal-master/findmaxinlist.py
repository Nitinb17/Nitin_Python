def findmax(list):
    print(max(list))
list = [1,5,7,26,99,9]
findmax(list)