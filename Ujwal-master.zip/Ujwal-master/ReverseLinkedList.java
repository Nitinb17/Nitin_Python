package com.TestAmazon.myPckage;





public class ReverseLinkedList {

	public static void main(String[] args) {
		
		node n = new node(); 
		node cur=null;
	 n.insert(cur, 0);
	n.insert(n, 1);
	 n.insert(n, 2);
		n.insert(n, 3);
		n.display(n);
	}

}

