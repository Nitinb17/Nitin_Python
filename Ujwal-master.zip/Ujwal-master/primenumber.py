number = 71

for i in range(2,number//2 + 1):
    if number % i == 0:
        print("Not prime number"," It is divisible by ", i)
        break

#if i > number//2:
print(i)

    
