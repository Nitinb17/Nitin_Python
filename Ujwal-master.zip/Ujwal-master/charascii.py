from tkinter.tix import INTEGER


str = "gulbargag"
print("Hello")
for x in str:
    y = ord(x)
    print(y)
print(chr(97))